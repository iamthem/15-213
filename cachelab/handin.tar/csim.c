/* Leandro Lopez
 * lslopez
*/

#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <stdbool.h>
#include <unistd.h>
#include <getopt.h>
#include <string.h>
#include <assert.h>

/*void create_blocks( size_t b, line *L ) {
    size_t block_size = 0x1 << (b);
    byte_array *B =  (byte_array *) malloc(sizeof(byte_array));
    B->len = block_size;
    B->next_word = (uint8_t *) malloc (sizeof(uint8_t));
    if (B == NULL || B->next_word == NULL){
        fprintf(stderr, "Cache initialization failed \n");
        exit(1);
    }

    for (i = 0; i < block_size - 1; i++) {
        uint8_t *tmp = (uint8_t *) malloc (sizeof(uint8_t));
        (B->next_word)++ = tmp

    }
    L->B = B;
}*/

/* Simulation of cache behavior */
/* Byte Array for Blocks */
typedef struct array_info byte_array;
struct array_info {
    size_t len;
    uint8_t *next_word;
};

typedef struct ins_info instruction;
struct ins_info {
    char *op;
    size_t addr;
    size_t size;
    instruction *next;
};

typedef struct line_info line;
struct line_info {
    size_t d_v_and_t;
    //byte_array *B;
};

/* Sets are represented as array of lines */
typedef struct chain_node set;
struct chain_node {
    size_t E;
    line *lines [];
};

/* cache data structure */
typedef struct cache_info cache;
struct cache_info {
    size_t E;
    size_t s;
    size_t b;
    instruction *init;
    set *sets [];
};

char **split_words ( char * line, char delim ) {
    int i = 1, j = 0, n = 0;

    char word[16];

    char **s = malloc(sizeof(word));
    s[0] = (char *) calloc (12, sizeof(char));
    s[1] = (char *) calloc (16, sizeof(char));

    while (line[i] != '\0'){
        if (line[i] == delim) {
            word[j] = '\0';
            strcpy(s[n], word);
            j = 0;
            n++;
            memset(word, 0, sizeof(word));

        } else word[j++] = line[i];
        i++;
    }
    s[n] = malloc(sizeof(word));
    strcpy(s[n], word);
    return s;
}

bool is_set_full ( set *S, size_t t, size_t E )
{
    size_t i;
    size_t tmp;

    for (i = 0; i < E; i++) {
        tmp = S->lines[i]->d_v_and_t;
        if ( ((tmp >> t) & 0x1) != 1) return false;
    }

    return true;
}

instruction *load_instructions( char *line , instruction *curr) {
    char **s, **t;
    char *ptr;
    char empty[1] = " ";
    instruction *tmp;

    tmp = (instruction *) malloc ( sizeof ( instruction ));
    s = split_words(line, ' ');
    t = split_words(strcat(empty, s[1]), ',');
    curr->op = s[0];
        curr->addr = strtoul(t[0], &ptr, 16);
        curr->size = strtoul(t[1], &ptr, 16);

        curr->next = tmp;
        return curr->next;
    }

    size_t create_set (set *S, size_t tag_counter, size_t E, size_t b, size_t s)
    {
        size_t i;
        for (i = 0; i < E; i++)
        {
            line *L = (line *) malloc(sizeof(line));
            if (L == NULL){
            fprintf(stderr, "Cache initialization failed \n");
            exit(1);
            }
            //create_blocks( b, L );
            L->d_v_and_t = tag_counter >> (s+b);
            S->lines[i] = L;
            tag_counter++;
        }
        return tag_counter;
    }

    void create_cache ( cache *C )
    {
        size_t i, tag_counter;
        tag_counter = 0;
        size_t num_sets = 0x1 << (C->s);

        for (i = 0; i < num_sets; i++)
        {
            set *S = (set *) malloc(sizeof(set));
            if (S == NULL){
            fprintf(stderr, "Cache initialization failed \n");
            exit(1);
            }
            tag_counter = create_set( S, tag_counter, C->E, C->b, C->s );
            C -> sets[i] = S;
        }
        return;
    }

    void read_file ( char *optarg, instruction *curr ) {
        FILE *file;
        instruction *node = curr;
        char line [20];
        file = fopen(optarg, "r");
        if (file == NULL) {
            fprintf(stderr, "Cache initialization failed \n");
            exit(1);
        }

        while (fgets(line, 20, file) != NULL) {
            node = load_instructions(line, node);
        }
        node = NULL;

        fclose(file);
        return;
    }


void write_cache( set *S, size_t addr, size_t E, size_t t) {
    size_t i, tmp, valid_bit;
    line *L;

    for (i = 0; i < E; i++) {
        L = S->lines[i];
        tmp = L->d_v_and_t;
        valid_bit = (tmp >> t) & 0x1;
        if (!valid_bit) {
            L->d_v_and_t = (0x1 << t) || addr;
            return;
        }
    }
    assert(is_set_full(S, t, E));
    return;
}

int read_cache(set *S, size_t addr, size_t E, size_t t) {
        size_t i, tmp, valid_bit;
        line *L;

        for (i = 0; i < E; i++) {
            L = S->lines[i];
            tmp = L->d_v_and_t;
            valid_bit = (tmp >> t) & 0x1;
        if ( valid_bit && ((tmp << (64-t)) >> (64-t)) == addr ) return 0;

        if (((tmp << (64-t)) >> (64-t)) == addr) {
            L->d_v_and_t = (1L << t);
            return 2;
        }
    }
    if (is_set_full(S, t, E)) return 1;
    write_cache(S, addr, E, t);
    return 2;
}

void simulate(cache *C, char *optarg) {
    size_t set_index, tag;
    int result;
    instruction *start;

    create_cache( C );

    size_t t = 64 - (C->b + C->s);
    instruction *curr = (instruction *) malloc ( sizeof ( instruction ));
    C->init = curr;
    curr->op = "init";
    curr->addr =  0;
    curr->size = 0;
    curr->next = (instruction *) malloc ( sizeof ( instruction ));

    read_file( optarg, curr->next );

    start = C->init->next;
    while ( start != NULL )
    {
        set_index = (start->addr << t) >> (64 - C->s);
        tag = start->addr >> (C->s + C->b);

        if (strcmp (start->op, "L") == 0 || strcmp (start->op, "S") == 0) {
            result = read_cache(C->sets[set_index], tag, C->E, t);
            switch (result) {
                case 0:
                    printf("L %zx,%zx hit\n", start->addr, start->size);
                    break;
                case 1:
                    printf("L %zx,%zx miss eviction\n",
                            start->addr, start->size);
                    break;
                case 2:
                    printf("L %zx,%zx miss\n", start->addr, start->size);
                    break;
            }
        } /*else {
            result = write_cache(C->sets[set_index], tag, C->E, t);
            switch (result) {
                case 0:
                    printf("S %zx,%zx hit\n", start->addr, start->size);
                    break;
                case 1:
                    printf("S %zx,%zx miss eviction\n",
                            start->addr, start->size);
                    break;
                case 2:
                    printf("S %zx,%zx miss\n", start->addr, start->size);
                    break;
            }
        }*/
        start = start->next;
    }
    return;
}


int main (int argc, char *argv[]) {

    int opt;
    cache *C = (cache *) malloc(sizeof(cache));

    if (C == NULL) {
        fprintf(stderr, "Cache initialization failed \n");
        return 1;
    }

    /* Iterate through all command line options
     * and specify the cache accordingly */
    while ((opt = getopt(argc, argv, "hvs:E:b:t:")) != -1) {
        char *ptr;
        switch (opt) {
            case 'h':
                printf("Useless Message \n");
                break;
            case 'v':
                printf("Verbosity \n");
                break;
            case 's':
                printf("%s\n", optarg);
                if (atoi(optarg) < 0) {
                    fprintf(stderr, "number of sets must be nonnegative \n");
                    return 1;
                } else C->s = strtoul(optarg, &ptr, 10);
                break;
            case 'E':
                if (atoi(optarg) < 1) {
                    fprintf(stderr, "Set must have at least one line\n");
                    return 1;
                } else C->E = strtoul(optarg, &ptr, 10);
                break;
            case 'b':
                if (atoi(optarg) < 0) {
                    fprintf(stderr, "number of blocks must be nonnegative \n");
                    return 1;
                } else C->b = strtoul(optarg, &ptr, 10);
                break;
            case 't':
                simulate(C, optarg);
                break;
        }
    }

    //free_cache
    return 0;
}
